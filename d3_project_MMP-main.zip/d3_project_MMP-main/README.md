# d3_project_MMP

This is a project I'm making to take a set of information regarding militant groups, their major events, and their relationships, and map it onto a timeline. 
